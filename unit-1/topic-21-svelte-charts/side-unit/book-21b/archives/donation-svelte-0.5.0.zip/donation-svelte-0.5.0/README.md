# Donation Svelte

Donation Client application for [Enterprise Web Development](https://tutors-svelte.netlify.app/#/course/wit-hdip-comp-sci-2020-ent-web-dev.netlify.app)

Consumes API implemented by 
- <https://github.com/wit-hdip-comp-sci-2020/donation-web>
