<script>
	import Header from "$lib/Header.svelte";
	import MainNavigator from "$lib/MainNavigator.svelte";
	import DonationMap from "$lib/DonationMap.svelte";
</script>

<Header>
	<MainNavigator />
</Header>

<DonationMap />
