<div class="box has-text-centered columns m-2">
	<a href="/donate" class="column is-4">
		<i class="fas fa-hand-holding-usd fa-3x" style="color:rgb(153, 196, 74)" />
	</a>
	<a href="/report" class="column is-4">
		<i class="fas fa-th-list fa-3x" style="color:rgb(63, 122, 139)" />
	</a>
	<a href="/logout" class="column is04">
		<i class="fas fa-sign-out-alt fa-3x" style="color:rgb(156, 70, 128)" />
	</a>
</div>
