Assignment II Specification

Concept, detail and grading spectrum for Assignment 2