16: Assignment 2 

Concept, detail and grading rubric