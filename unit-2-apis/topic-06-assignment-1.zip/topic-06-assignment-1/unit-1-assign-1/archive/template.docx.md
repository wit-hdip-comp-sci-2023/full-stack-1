Project Submission Template

An archive of a word document to be submitted with assignment 1