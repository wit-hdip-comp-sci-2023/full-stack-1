Whitespace, Commas & Semicolons

Javascript Style Guide from AirBnB