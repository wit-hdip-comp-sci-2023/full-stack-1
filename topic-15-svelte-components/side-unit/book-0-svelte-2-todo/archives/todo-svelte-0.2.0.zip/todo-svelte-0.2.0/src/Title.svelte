<script>
  export let title;
  export let subTitle;
</script>
<div class="box has-text-centered">
  <div class="title"> {title} </div>
  <div class="subtitle"> {subTitle} </div>
</div>
