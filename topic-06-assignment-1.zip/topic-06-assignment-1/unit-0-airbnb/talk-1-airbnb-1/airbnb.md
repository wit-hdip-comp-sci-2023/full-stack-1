Naming Conventions & Comments

Javascript Style Guide from AirBnB