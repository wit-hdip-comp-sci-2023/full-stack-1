06: Assignment 1 

Concept, detail and grading rubric