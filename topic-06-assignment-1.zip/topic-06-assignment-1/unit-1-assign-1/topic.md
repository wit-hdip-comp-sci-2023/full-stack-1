Assignment 1
