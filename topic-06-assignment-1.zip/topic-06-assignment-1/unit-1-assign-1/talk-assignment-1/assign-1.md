Assignment 1 Specification

Concept, detail and grading spectrum for Assignment 1